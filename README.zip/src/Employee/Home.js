import React from 'react'

function MHome() {
  return (
    <div>
      <h1>home</h1>
    </div>
  )
}

export default MHome